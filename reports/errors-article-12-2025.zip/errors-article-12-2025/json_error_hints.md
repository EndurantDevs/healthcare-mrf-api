# JSON Error Hints

Higher-level view of invalid JSON causes with example log links.

- Non-UTF8 bytes present: 230 errors; example https://www.healthporta.com/healthcare-data/issuer/antidote-health-plan-of-ohio-31981/import/#31981-520117768
- HTML returned instead of JSON: 121 errors; example https://www.healthporta.com/healthcare-data/issuer/blue-cross-and-blue-shield-of-alabama-46944/import/#46944--296298049
- Truncated/incomplete JSON: 3 errors; example https://www.healthporta.com/healthcare-data/issuer/baylor-scott-white-health-plan-40788/import/#40788-1666855757
- Lexical parse error (bad token): 3 errors; example https://www.healthporta.com/healthcare-data/issuer/dentegra-insurance-company-11339/import/#11339--1268439456
