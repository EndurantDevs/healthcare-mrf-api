# JSON Error Categorization

Breakdown of invalid JSON errors across all issuers/sources. See also report/json_subtype_by_source.xls for the tabular view.

## By Subtype (all sources)

- Invalid UTF-8 bytes in JSON: 230 errors; example https://www.healthporta.com/healthcare-data/issuer/antidote-health-plan-of-ohio-31981/import/#31981-520117768
- HTML or non-JSON returned: 124 errors; example https://www.healthporta.com/healthcare-data/issuer/blue-cross-and-blue-shield-of-alabama-46944/import/#46944--296298049
- Truncated/incomplete JSON: 3 errors; example https://www.healthporta.com/healthcare-data/issuer/baylor-scott-white-health-plan-40788/import/#40788-1666855757

## By Subtype × Source

- Invalid UTF-8 bytes in JSON — providers: 228 errors
- HTML or non-JSON returned — json_index: 44 errors
- HTML or non-JSON returned — providers: 40 errors
- HTML or non-JSON returned — plans: 40 errors
- Truncated/incomplete JSON — plans: 3 errors
- Invalid UTF-8 bytes in JSON — plans: 2 errors